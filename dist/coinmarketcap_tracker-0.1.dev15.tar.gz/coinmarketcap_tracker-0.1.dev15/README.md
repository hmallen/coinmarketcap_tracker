# Coinmarketcap Tracker

Tracks Coinmarketcap.com data for selected products over time.

<b>To Do:</b>
- Check creation time of historical_data.json to make sure tracker actually running and not stuck/aborted
